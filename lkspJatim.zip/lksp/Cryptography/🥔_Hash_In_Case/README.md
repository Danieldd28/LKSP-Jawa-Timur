# 🥔 Hash In Case

**Category** : Cryptography
**Points** : 484

This one is pretty simple. This is a simple encryptor. Maybe you can crack our flag if you understand how encrytion work. Just do your best~

```bash
nc 13.212.83.182 11000
```

Author: `Nemesis`

## Files : 
 - [chall.zip](./chall.zip)


