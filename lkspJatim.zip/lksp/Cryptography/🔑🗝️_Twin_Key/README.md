# 🔑🗝️ Twin Key

**Category** : Cryptography
**Points** : 500

Welcome to our humble encryptor. Unfortunately, it seems that something wrong with our encryptor, as someone can still decrypt our encryption even without knowing all the required data. Can someone figure it out what's wrong with our encryption? we are giving out a big prize for someone that can crack our encryptor with limited information!!

```bash
nc <HOST> <12000>
```

Author: `Nemesis`

## Files : 
 - [chall.zip](./chall.zip)


