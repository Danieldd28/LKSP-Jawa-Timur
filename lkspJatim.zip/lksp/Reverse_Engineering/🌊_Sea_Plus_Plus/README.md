# 🌊 Sea Plus Plus

**Category** : Reverse Engineering
**Points** : 484

`std::vector` is cooler than your typical `char arr[]`.  Are you able to get the LKS Flag back to the original state?

Author: `aseng`


## Files : 
 - [vector.exe](./vector.exe)
 - [vector.cpp](./vector.cpp)


