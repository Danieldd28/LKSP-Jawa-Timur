flag = ['c', 'p', '_', 'r', 'v', '0', 'c', '5', 'w', '4', 't', '+', '3', '_', '+']
swaps = [
    (14, 0), (1, 2), (2, 13), (3, 11), (4, 6), (5, 4),
    (6, 0), (7, 8), (8, 7), (9, 9), (10, 3), (11, 5),
    (12, 1), (13, 10), (14, 12)
]

# Apply swaps
for swap in swaps:
    flag[swap[0]], flag[swap[1]] = flag[swap[1]], flag[swap[0]]

# Convert the list to a string
result = ''.join(flag)
print(result)
