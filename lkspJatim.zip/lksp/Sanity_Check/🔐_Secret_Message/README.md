# 🔐 Secret Message

**Category** : Sanity Check
**Points** : 1

Shift all the alphabets below with the same offset to get a free flag! Some says it can be "ROT"-en or de-CIPHER-ed

`
Dlsjvtl av SRZW Qhapt! Nla fvby JHLZHY'lk mshn olyl -> SRZQHAPT{mylllll_mshn_av_thrl_fvby_tluahs_zayvun}
`





